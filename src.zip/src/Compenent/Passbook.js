import React from 'react'

function Passbook() {
    return (
        <>
            <div className='color'>
                <div class="heading_text">
                    <h2>Your Passbook has been ready!</h2>
                </div>
              
            </div>
        </>
    )
}

export default Passbook
